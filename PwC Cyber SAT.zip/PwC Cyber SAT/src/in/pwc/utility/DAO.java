package in.pwc.utility;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import in.pwc.beans.User;

public class DAO {
	
	public static User doLogin(User user){
		
Connection con = DbConnector.doConnect(); 
		
		PreparedStatement ps = null;
		String query = "SELECT * FROM user_details WHERE email = ? and password = ?";
		try {
			ps = con.prepareStatement(query);
			
			ps.setString(1,user.getEmail());
			ps.setString(2,user.getPassword());
			
			ResultSet rs = ps.executeQuery();
			
			System.out.println(rs.toString());
			System.out.println(rs.next());
			
			if(rs.next()){
				user.setUserName(rs.getString("user_name"));
				System.out.println(user.getUserName());
				user.setUserId(rs.getString("user_id"));
				//con.close();
				return user;
			}
			
			else{
				
				System.out.println("Query not executed");
				return null;
			}
						
		} 
		catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		try {
			con.close();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return null;
					
	}
	
	public static boolean doRegister(User newUser){
		
		Connection con = DbConnector.doConnect(); boolean status = false;
		
		PreparedStatement ps = null;
		String query = "INSERT INTO user_details (user_name, password, email, organization, user_id, account_privilege) VALUES(?,?,?,?,?,?)";
		
		try {
			
			ps = con.prepareStatement(query);
			ps.setString(1, newUser.getUserName());
			ps.setString(2, newUser.getPassword());
			ps.setString(3, newUser.getEmail());
			ps.setString(4, newUser.getOrganization());
			ps.setString(5, newUser.getUserId());
			ps.setString(6, newUser.getAccountType());
		
			ps.executeUpdate();
			 status = true;
			
			
			if(status){
				con.close();
				return true;
			}
			else{
				con.close();
				return false;
			}
		
		}
		catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return false;
		
	}
}
