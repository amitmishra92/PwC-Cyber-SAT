package in.pwc.utility;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

public class DbConnector {
	
	@SuppressWarnings("finally")
	public static Connection doConnect(){
		
		
			try {
				Class.forName("com.mysql.jdbc.Driver").newInstance();
			} catch (InstantiationException | IllegalAccessException | ClassNotFoundException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		

		Connection con = null;
		try {
			con = DriverManager.getConnection("jdbc:mysql://localhost/pwc_cyber_sat", "root", "");
			
		} 
		catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		finally{
			return con;
		}
	}
	
	
}
